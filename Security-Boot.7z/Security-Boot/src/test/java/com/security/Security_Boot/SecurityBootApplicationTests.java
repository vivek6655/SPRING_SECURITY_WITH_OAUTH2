package com.security.Security_Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
