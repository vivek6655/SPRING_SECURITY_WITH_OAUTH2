package com.security.Security_Boot.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.GetExchange;

@RestController
public class HelloWorldController {
	
	private final Logger LOGGER=LoggerFactory.getLogger(getClass());
	
	@GetMapping("/hello-world")
	public String getHelloWoirld() {
		return "Hello-World";
	}
	
	@GetMapping("/todos")
	public List<Todo> retrieveAllTodos() {
		return List.of(new Todo("vivek","i am user"),new Todo("nisha","i am user"));
	}

	@PostMapping("/todos/create")
	public Todo createTodos(@RequestBody Todo todo) {
		LOGGER.info("crete user and todo :" +todo);
		return todo;
	}
	
	@GetMapping("/login")
	String login() {
		return "login";
	}

}

record Todo(String userName , String description) {}