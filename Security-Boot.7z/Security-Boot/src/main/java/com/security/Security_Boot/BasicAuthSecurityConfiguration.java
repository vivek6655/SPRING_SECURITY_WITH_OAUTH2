package com.security.Security_Boot;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;

//@Configuration
//@EnableMethodSecurity
public class BasicAuthSecurityConfiguration {
		
	@Bean
	DefaultSecurityFilterChain securityFsilterChain(HttpSecurity http) throws Exception {
		
		http.authorizeHttpRequests(auth->{
			auth.anyRequest().authenticated();
		});
		
		http.sessionManagement(session->{
			session.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		});
		
		http.httpBasic();
		http.headers(header->header.frameOptions().sameOrigin());
		http.csrf(csrf->csrf.disable());
		http.formLogin();
		return http.build();
	}

//	@Bean
//	SecurityFilterChain securityFsilterChains(HttpSecurity http) throws Exception {
//		
//		http.csrf(csrf->csrf.disable());
//		
//		http.authorizeHttpRequests(
//		auth->
//		auth.requestMatchers("/home/user").hasRole("USER")
//		.requestMatchers("/api/moderator/**").hasAnyRole("ADMIN", "USER")
//		.requestMatchers("/home/admin").hasRole("ADMIN")
//		.requestMatchers("/home/public").permitAll()
//		.anyRequest().authenticated());
//			
//		http.formLogin();
////		http.formLogin(form -> form
////			.loginPage("/login")
////			.permitAll());
//		
//		return http.build();
//	}
	
	
	// in memory database 
	
//	@Bean
//	public UserDetailsService userDetailsService() {
//		
//		UserDetails user = User.withUsername("vivek")
//		    .password("{noop}dummy").roles("USER").build();
//		
//		var admin = User.withUsername("nisha")
//			    .password("{noop}dummy").roles("ADMIN").build();
//		
//		return new InMemoryUserDetailsManager(user,admin);
//	}
	
//	  @Bean
//	    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//	        http
//	            .csrf(csrf -> csrf.disable()) // Disable CSRF for simplicity
//	            .authorizeHttpRequests(auth -> auth
//	                .requestMatchers("/auth/welcome").permitAll() // Permit all access to /auth/welcome
//	                .requestMatchers("/auth/user/**").authenticated() // Require authentication for /auth/user/**
//	                .requestMatchers("/auth/admin/**").authenticated() // Require authentication for /auth/admin/**
//	            )
//	            .formLogin(withDefaults()); // Enable form-based login
//	        
//	        return http.build();
//	    }

	
	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder()
				.setType(EmbeddedDatabaseType.H2)
				.addScript(JdbcDaoImpl.DEFAULT_USER_SCHEMA_DDL_LOCATION).build();
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();	
	}
	
	
	@Bean
	public UserDetailsService userDetailsService(DataSource dataSource) {
		
		UserDetails user = User.withUsername("vivek")
		    .password("system123123###")
		    .passwordEncoder(str->passwordEncoder().encode(str))
		    .roles("USER").build();
		
		var admin = User.withUsername("nisha")
				 .password("nisha@123")
				 .passwordEncoder(str->passwordEncoder().encode(str))
			    .roles("ADMIN","USER").build();
		
		JdbcUserDetailsManager jdbcUserDetailsManager=new JdbcUserDetailsManager(dataSource);
		jdbcUserDetailsManager.createUser(user);
		jdbcUserDetailsManager.createUser(admin);
		return  jdbcUserDetailsManager;
	}

}
