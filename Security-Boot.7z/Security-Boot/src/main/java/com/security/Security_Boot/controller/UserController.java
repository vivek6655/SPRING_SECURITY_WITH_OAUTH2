package com.security.Security_Boot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/home")
//@CrossOrigin
public class UserController {
	
	@Autowired
	private Environment environment;
	
	@GetMapping("/public")
	public String getHelloWoirld() {
		String port =environment.getProperty("local.server.port");
		return port+": this is public port and it is dynamic port ";
	}
	
	@GetMapping("/api/moderator/hello-world")
	public String getHelloWoirldApi() {
		return "public_Hello-World_with_moderator ";
	}
	
	
	//@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	@GetMapping("/user")
	public List<Todo> retrieveAllTodosUsers() {
		return List.of(new Todo("vivek","i am user"),new Todo("nisha","i am user"));
	}
	
	@GetMapping("/admin")
	public List<Todo> retrieveAllTodosAdmin() {
		return List.of(new Todo("Prem","i am admin"),new Todo("Krishan","i am admin"));
	}

	@GetMapping("/admin/aligarh")
	public List<Todo> retrieveAllTodosAdminAligarh() {
		return List.of(new Todo("Prem","i am admin ALIGARH"),new Todo("Krishan","i am admin ALIGARH"));
	}
	
	
	@PostMapping("/headers")
	public ResponseEntity<Map<String ,String>> getHeader(
			@RequestHeader(value="Accept") String acceptHeader 
		   ,@RequestHeader(value="Authorization") String authorizationHeader
		   ) {
		
		Map<String ,String> returnValue=new HashMap<String,String>();
		returnValue.put("Accept", acceptHeader);
		returnValue.put("Authorization", authorizationHeader);
		return ResponseEntity.status(HttpStatus.OK).body(returnValue); 
		
	}
	
	
}
