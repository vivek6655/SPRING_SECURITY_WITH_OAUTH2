package com.security.Security_Boot.jwt_v2;

public class JwtResponse {

}
