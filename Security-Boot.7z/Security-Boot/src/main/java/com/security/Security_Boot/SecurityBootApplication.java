package com.security.Security_Boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityBootApplication.class, args);
		System.out.println("Security-Boot--------------");
	}

}
